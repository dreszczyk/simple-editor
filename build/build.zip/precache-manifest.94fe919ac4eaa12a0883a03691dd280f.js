self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8635a2012f544b21ac553f7aa1fbb4f2",
    "url": "/simple-editor/index.html"
  },
  {
    "revision": "3aa254d0944f80818b20",
    "url": "/simple-editor/static/css/2.5a75ea7a.chunk.css"
  },
  {
    "revision": "9b714ff50b76778573f6",
    "url": "/simple-editor/static/css/main.8e3f3edd.chunk.css"
  },
  {
    "revision": "3aa254d0944f80818b20",
    "url": "/simple-editor/static/js/2.02494b29.chunk.js"
  },
  {
    "revision": "9b714ff50b76778573f6",
    "url": "/simple-editor/static/js/main.c158992f.chunk.js"
  },
  {
    "revision": "6700721b7adc801c6ae2",
    "url": "/simple-editor/static/js/runtime~main.d4823f31.js"
  }
]);